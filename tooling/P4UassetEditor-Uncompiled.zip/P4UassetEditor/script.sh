#!/bin/bash
yes '' | ./encode.bat
cp -r _OUTPUT/* /c/Users/andre/Desktop/castoc/_EDIT/Carrot4/Content
cd /c/Users/andre/Desktop/castoc
yes '' | ./PACKFILES.bat
cp -r _OUTPUT/* /b/Games/Pikmin\ 4/user/load/0100B7C00933A000/TestMod/romfs/Carrot4/Content/Paks
